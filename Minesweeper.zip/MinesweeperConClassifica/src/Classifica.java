import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.JOptionPane;

public class Classifica {

    /**
     * Scrive il record nel file.
     * @param difficolta Stringa che identifica il livello
     * @param tempoSecondi Il tempo impiegato espresso in secondi (int)
     */
    public static void scrittura(String difficolta, int tempoSecondi) {
        String nomeFile = "classifica" + difficolta;

        String nome = JOptionPane.showInputDialog(null, "Inserisci il nome del giocatore:");

        if (nome == null || nome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nome non valido. Salvataggio annullato.");
            return;
        }

        nome = nome.trim().replace(";", ",");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nomeFile, true))) {
            // Salviamo il tempo come numero intero
            writer.write(nome + ";" + tempoSecondi);
            writer.newLine();
            JOptionPane.showMessageDialog(null, "Salvataggio completato!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Errore durante la scrittura: " + e.getMessage());
        }
    }

    public static void lettura(String difficolta) {
        String nomeFile = "classifica" + difficolta;

        try {
            if (Files.exists(Paths.get(nomeFile))) {
                List<String> lines = new ArrayList<>(Files.readAllLines(Paths.get(nomeFile)));

                // Ordina le righe convertendo la parte del tempo in int
                lines.sort(Comparator.comparingInt(Classifica::estraiSecondi));

                StringBuilder sb = new StringBuilder();
                sb.append("===== CLASSIFICA ").append(difficolta.replace(".txt", "").toUpperCase()).append(" =====\n");

                int posizione = 1;
                for (String line : lines) {
                    String[] parts = line.split(";");
                    if (parts.length >= 2) {
                        int secondiTotali = Integer.parseInt(parts[1]);
                        
                        sb.append(posizione).append(") ")
                          .append(parts[0]).append(" - ")
                          .append(formattaTempo(secondiTotali)).append("\n");
                        posizione++;
                    }
                }

                if (posizione == 1) {
                    sb.append("Nessun risultato presente.");
                }

                JOptionPane.showMessageDialog(null, sb.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Il file non esiste ancora.");
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Errore durante la lettura o conversione: " + e.getMessage());
        }
    }

    // Estrae i secondi dalla riga salvata per l'ordinamento
    private static int estraiSecondi(String line) {
        try {
            String[] parts = line.split(";");
            return Integer.parseInt(parts[1].trim());
        } catch (Exception e) {
            return Integer.MAX_VALUE;
        }
    }

    // Helper per mostrare il tempo in formato leggibile mm:ss nella classifica
    private static String formattaTempo(int secondiTotali) {
        int m = secondiTotali / 60;
        int s = secondiTotali % 60;
        return String.format("%02d:%02d", m, s);
    }
}