
import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JButton;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author nonGalimberti
 */

import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
public class Finestra1 extends javax.swing.JFrame {

    /*private AscoltaBottone ascoltaBottone = new AscoltaBottone();
    
    private class AscoltaBottone implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            for (int i = 0; i < campoServer.getWidth(); i++)
                for(int j = 0; j < campoServer.getHeight(); j++)
                {
                    if(e.getSource()==campoClient[i][j])
                    { 
                        if(primoClick)
                        {
                            campoServer.stesuraMine(i, j);
                            primoClick = false;
                        }
                        uncover(i, j);
                        
                        //Solo con tasto sinistro disattivo il listener
                    }
                }
        }
        
    }*/
    
    private class AscoltaMouse extends MouseAdapter 
    {
        @Override
        
        public void mousePressed(MouseEvent e)
        {
            JButton bottone = (JButton) e.getSource();
            //Recupero il bottone premuto (evita doppio for)

            int x = (int) bottone.getClientProperty("x");
            int y = (int) bottone.getClientProperty("y");
            //Recupero le sue coordinate
    
            if(e.getButton() == MouseEvent.BUTTON1) {   
                //Tasto mouse sinistro
                
                //Se e' il primo click
                if(primoClick)
                {
                    //Stendo le mine (evito mina al primo click)
                    campoServer.stesuraMine(x, y);
                    primoClick = false;
                    
                    //Fa partire il timer
                    if (gameTimer != null) {
                        gameTimer.stop();
                    }

                    //Azzera il conteggio
                    tempo = 0;
                    timerLabel.setText("000");

                    //Crea un timer (1 unita' = 1000 ms)
                    gameTimer = new Timer(1000, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            tempo++;
                            timerLabel.setText(String.format("%03d", tempo));
                        }
                    });
                    gameTimer.start();
                }
                
                //Faccina in anticipazione
                resetButton.setIcon(new ImageIcon(getClass().getResource("SmileyPog.png")));
            
                //Scopro sempre il bottone premuto
                uncover(x, y);
                
            } else if(e.getButton() == MouseEvent.BUTTON3) {
                //Tasto mouse destro
                
                //Se e' il primo click
                if(primoClick)
                    return;
                //Non fa niente
                
                //Se già scoperta
                if (cellaScoperta[x][y] == 1) {
                    return;
                }

                // Se già una bandiera
                if (cellaScoperta[x][y] == 2) {
                    
                    // Torna a casella coperta
                    campoClient[x][y].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile11.png")));
                    cellaScoperta[x][y] = 0;
                    
                    bombCounter--;
                    bombCounterLabel.setText(String.valueOf(numBombe - bombCounter));
                    
                } else if (cellaScoperta[x][y] == 0) {
                    
                    // Altrimenti metti bandiera
                    if(mistoPrato)
                    {    
                        randomNum = rand.nextInt(9);
                        campoClient[x][y].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile10-" + randomNum + ".png")));
                    }
                    else
                        campoClient[x][y].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile10.png"))); 
                    cellaScoperta[x][y] = 2;
                    
                    bombCounter++;
                    bombCounterLabel.setText(String.valueOf(numBombe - bombCounter));
                    }
            }
        }
        
        public void mouseReleased(MouseEvent e) {}
    }
    

    /**
     * Creates new form Finestra1
     */
    public Finestra1() {
        initComponents();
        
        //Crea il campo di gioco (lato server)
        campoServer = new GameBoard(lunghezza, altezza, numBombe);
        
        //Solo il panel di start visibile
        MenuStartPanel.setVisible(true);
        CampoDiGiocoPanelBase.setVisible(false);
        DifficultyEditorPanel.setVisible(false);
        ThemeEditorPanel.setVisible(false);
        ClassificaSelectorPanel.setVisible(false);
        CreditiPanel.setVisible(false);

        //Ridimensionato
        pack();
        setSize(272, 360);
    }

    void uncover (int x, int y)
    {
        //Quando si scopre una casella
        
        //Check se e' in bounds
        if(x < 0 || x >= campoServer.getWidth() || y < 0 || y >= campoServer.getHeight())
            return;
        
        //Check se e' gia' stata scoperta
        if(cellaScoperta[x][y] == 1)
            return;
        
        //Tra l'altro non serve mettere un else qua' perché se avviene l'if la funzione
        //Termina quindi tutto quello che viene dopo e' come un else
        
        //Scrivi la cella come scoperta
        cellaScoperta[x][y] = 1;
        
        //Setta il bottone all'immagine corrispondente
        int valore = campoServer.getValueOnBoard(x, y);
        //campoClient[x][y].setText(String.valueOf(valore));
        
        if (valore == 0)
            if (mistoSpazio) {
                randomNum = rand.nextInt(9);
                campoClient[x][y].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile" + valore + "-" + randomNum + ".png")));
            } else {
                campoClient[x][y].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile" + valore + ".png")));
            }

    if(valore!=0){
        campoClient[x][y].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile" + valore + ".png")));
    }
        
        //Reso non piu' cliccabile
        campoClient[x][y].removeMouseListener(ascoltaMouse);
        
        //Se la tile scoperta e' una mina
        if (campoServer.getValueOnBoard(x, y) == 9)
        {
            //Faccina morta
            resetButton.setIcon(new ImageIcon(getClass().getResource("SmileyDead.png")));   
            
            JOptionPane.showMessageDialog(this, "Hai scoperto una mina, hai perso!!", "Sconfitta", 0);
            
            //Ferma il timer
            if (gameTimer != null) {
                gameTimer.stop();
            }
            
            for (int i = 0; i < campoServer.getWidth(); i++)
                for(int j = 0; j < campoServer.getHeight(); j++)
                {
                     try {
                        //Nessun tasto piu' cliccabile
                        campoClient[i][j].removeMouseListener(ascoltaMouse);
                    } catch (Exception ex) {
                        //Se non c'è listener non fa nulla
                    }
                    
                    //Scopre tutte le restanti mine
                    if (campoServer.getValueOnBoard(i, j) == 9)
                        //campoClient[i][j].setText(String.valueOf(valore));
                        campoClient[i][j].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile9.png")));
                }
            return;
            
        } else if(campoServer.getValueOnBoard(x, y) == 0)
        {
            //Se scopro una cella vuota
            
            //Lavoro sulle 8 celle adiacenti a quella vuota
            for(int i = x - 1; i <= x + 1; i++)
                for(int j = y - 1; j <= y + 1; j++)
                {
                    //Le scopro
                    uncover(i, j);
                }
        }
        
        resetButton.setIcon(new ImageIcon(getClass().getResource("Smiley.png")));
        
        tilesScoperte++;
        
        //Se hanno scoperto tutte le tiles safe (tot tiles - num di bombe)
        if(tilesScoperte == campoServer.getWidth() * campoServer.getHeight() - campoServer.getNumBombe())
        {
            //Non piu' cliccabili
            JOptionPane.showMessageDialog(this, "Non hai scoperto nessuna mina, hai vinto!!", "Vittoria", 1);
            
            //Ferma il timer
            if (gameTimer != null) {
                gameTimer.stop();
            }
            
            for (int i = 0; i < campoServer.getWidth(); i++)
                for(int j = 0; j < campoServer.getHeight(); j++)
                    campoClient[i][j].removeMouseListener(ascoltaMouse);
                    //Cambiato perché erano ancora cliccabili
                    
                    Classifica.scrittura(difficolta, tempo);

            }

        
    }
    
    void cambio(String mess, char genere)
    {
        JOptionPane.showMessageDialog(this, mess + " aggiornat" + genere + " con successo!", "Aggiornamento", 1);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MenuStartPanel = new javax.swing.JPanel();
        NuovaPartitaBottone = new javax.swing.JButton();
        DifficoltaBottone = new javax.swing.JButton();
        TemaBottone = new javax.swing.JButton();
        ClassificaBottone = new javax.swing.JButton();
        CreditiBottone = new javax.swing.JButton();
        CampoDiGiocoPanelBase = new javax.swing.JPanel();
        CampoDiGiocoPanelTop = new javax.swing.JPanel();
        homeButton = new javax.swing.JButton();
        bombCounterLabel = new javax.swing.JLabel();
        timerLabel = new javax.swing.JLabel();
        resetButton = new javax.swing.JButton();
        CampoDiGiocoPanelCenter = new javax.swing.JPanel();
        DifficultyEditorPanel = new javax.swing.JPanel();
        difficultyEasyButton = new javax.swing.JButton();
        difficultyMediumButton = new javax.swing.JButton();
        difficultyAdvancedButton = new javax.swing.JButton();
        DifficultyEditorReturnButton = new javax.swing.JButton();
        ThemeEditorPanel = new javax.swing.JPanel();
        ThemeBaseButton = new javax.swing.JButton();
        ThemeDarkButton = new javax.swing.JButton();
        ThemePratoFioritoButton = new javax.swing.JButton();
        ThemeMareButton = new javax.swing.JButton();
        ThemeCimiteroButton = new javax.swing.JButton();
        ThemeSpazioButton = new javax.swing.JButton();
        ThemeRandomButton = new javax.swing.JButton();
        ThemeEditorReturnButton = new javax.swing.JButton();
        ClassificaSelectorPanel = new javax.swing.JPanel();
        ClassificaEasyButton = new javax.swing.JButton();
        ClassificaMediumButton = new javax.swing.JButton();
        ClassificaAdvancedButton = new javax.swing.JButton();
        ClassificaReturnButton = new javax.swing.JButton();
        CreditiPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        TilePreferitaGiacomo = new javax.swing.JLabel();
        TilePreferitaThomas = new javax.swing.JLabel();
        CreditsReturnButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(20000, 20000));
        setPreferredSize(new java.awt.Dimension(262, 282));

        MenuStartPanel.setBackground(new java.awt.Color(192, 192, 192));

        NuovaPartitaBottone.setText("Nuova Partita");
        NuovaPartitaBottone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NuovaPartitaBottoneActionPerformed(evt);
            }
        });

        DifficoltaBottone.setText("Difficoltà");
        DifficoltaBottone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DifficoltaBottoneActionPerformed(evt);
            }
        });

        TemaBottone.setText("Tema");
        TemaBottone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TemaBottoneActionPerformed(evt);
            }
        });

        ClassificaBottone.setText("Classifica");
        ClassificaBottone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassificaBottoneActionPerformed(evt);
            }
        });

        CreditiBottone.setText("Crediti");
        CreditiBottone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreditiBottoneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MenuStartPanelLayout = new javax.swing.GroupLayout(MenuStartPanel);
        MenuStartPanel.setLayout(MenuStartPanelLayout);
        MenuStartPanelLayout.setHorizontalGroup(
            MenuStartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuStartPanelLayout.createSequentialGroup()
                .addContainerGap(67, Short.MAX_VALUE)
                .addGroup(MenuStartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MenuStartPanelLayout.createSequentialGroup()
                        .addGroup(MenuStartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(NuovaPartitaBottone, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                            .addComponent(DifficoltaBottone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TemaBottone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ClassificaBottone, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(65, 65, 65))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MenuStartPanelLayout.createSequentialGroup()
                        .addComponent(CreditiBottone, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        MenuStartPanelLayout.setVerticalGroup(
            MenuStartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuStartPanelLayout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(NuovaPartitaBottone)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(DifficoltaBottone)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TemaBottone)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ClassificaBottone)
                .addGap(31, 31, 31)
                .addComponent(CreditiBottone)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        CampoDiGiocoPanelBase.setBackground(new java.awt.Color(120, 60, 120));
        CampoDiGiocoPanelBase.setLayout(new java.awt.BorderLayout());

        CampoDiGiocoPanelTop.setBackground(new java.awt.Color(128, 128, 128));

        homeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeButtonActionPerformed(evt);
            }
        });

        bombCounterLabel.setText("Bombe");

        timerLabel.setText("Timer");

        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CampoDiGiocoPanelTopLayout = new javax.swing.GroupLayout(CampoDiGiocoPanelTop);
        CampoDiGiocoPanelTop.setLayout(CampoDiGiocoPanelTopLayout);
        CampoDiGiocoPanelTopLayout.setHorizontalGroup(
            CampoDiGiocoPanelTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CampoDiGiocoPanelTopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bombCounterLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(homeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(110, 110, 110)
                .addComponent(timerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        CampoDiGiocoPanelTopLayout.setVerticalGroup(
            CampoDiGiocoPanelTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CampoDiGiocoPanelTopLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(CampoDiGiocoPanelTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(homeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(CampoDiGiocoPanelTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(timerLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                        .addComponent(bombCounterLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(resetButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        CampoDiGiocoPanelBase.add(CampoDiGiocoPanelTop, java.awt.BorderLayout.PAGE_START);

        CampoDiGiocoPanelCenter.setBackground(new java.awt.Color(192, 192, 192));
        CampoDiGiocoPanelCenter.setLayout(new java.awt.GridLayout(9, 9));
        CampoDiGiocoPanelBase.add(CampoDiGiocoPanelCenter, java.awt.BorderLayout.CENTER);

        DifficultyEditorPanel.setBackground(new java.awt.Color(192, 192, 192));

        difficultyEasyButton.setText("Facile");
        difficultyEasyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                difficultyEasyButtonActionPerformed(evt);
            }
        });

        difficultyMediumButton.setText("Medio");
        difficultyMediumButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                difficultyMediumButtonActionPerformed(evt);
            }
        });

        difficultyAdvancedButton.setText("Difficile");
        difficultyAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                difficultyAdvancedButtonActionPerformed(evt);
            }
        });

        DifficultyEditorReturnButton.setText("Return");
        DifficultyEditorReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DifficultyEditorReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout DifficultyEditorPanelLayout = new javax.swing.GroupLayout(DifficultyEditorPanel);
        DifficultyEditorPanel.setLayout(DifficultyEditorPanelLayout);
        DifficultyEditorPanelLayout.setHorizontalGroup(
            DifficultyEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DifficultyEditorPanelLayout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addGroup(DifficultyEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DifficultyEditorPanelLayout.createSequentialGroup()
                        .addGroup(DifficultyEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(difficultyEasyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(difficultyMediumButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(difficultyAdvancedButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DifficultyEditorPanelLayout.createSequentialGroup()
                        .addComponent(DifficultyEditorReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        DifficultyEditorPanelLayout.setVerticalGroup(
            DifficultyEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DifficultyEditorPanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(difficultyEasyButton)
                .addGap(18, 18, 18)
                .addComponent(difficultyMediumButton)
                .addGap(18, 18, 18)
                .addComponent(difficultyAdvancedButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(DifficultyEditorReturnButton)
                .addContainerGap())
        );

        ThemeEditorPanel.setBackground(new java.awt.Color(192, 192, 192));

        ThemeBaseButton.setText("Base");
        ThemeBaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeBaseButtonActionPerformed(evt);
            }
        });

        ThemeDarkButton.setText("Scuro");
        ThemeDarkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeDarkButtonActionPerformed(evt);
            }
        });

        ThemePratoFioritoButton.setText("Prato Fiorito");
        ThemePratoFioritoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemePratoFioritoButtonActionPerformed(evt);
            }
        });

        ThemeMareButton.setText("Sito Navale");
        ThemeMareButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeMareButtonActionPerformed(evt);
            }
        });

        ThemeCimiteroButton.setText("Cimitero");
        ThemeCimiteroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeCimiteroButtonActionPerformed(evt);
            }
        });

        ThemeSpazioButton.setText("Spazio");
        ThemeSpazioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeSpazioButtonActionPerformed(evt);
            }
        });

        ThemeRandomButton.setText("Random");
        ThemeRandomButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeRandomButtonActionPerformed(evt);
            }
        });

        ThemeEditorReturnButton.setText("Return");
        ThemeEditorReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemeEditorReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ThemeEditorPanelLayout = new javax.swing.GroupLayout(ThemeEditorPanel);
        ThemeEditorPanel.setLayout(ThemeEditorPanelLayout);
        ThemeEditorPanelLayout.setHorizontalGroup(
            ThemeEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ThemeEditorPanelLayout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(ThemeEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ThemeEditorPanelLayout.createSequentialGroup()
                        .addGroup(ThemeEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(ThemeCimiteroButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ThemeBaseButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ThemeDarkButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ThemePratoFioritoButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ThemeMareButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ThemeSpazioButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ThemeRandomButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(43, 43, 43))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ThemeEditorPanelLayout.createSequentialGroup()
                        .addComponent(ThemeEditorReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        ThemeEditorPanelLayout.setVerticalGroup(
            ThemeEditorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ThemeEditorPanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(ThemeBaseButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ThemeDarkButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ThemePratoFioritoButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ThemeMareButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ThemeCimiteroButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ThemeSpazioButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ThemeRandomButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(ThemeEditorReturnButton)
                .addContainerGap())
        );

        ClassificaSelectorPanel.setBackground(new java.awt.Color(192, 192, 192));

        ClassificaEasyButton.setText("Classifica Easy");
        ClassificaEasyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassificaEasyButtonActionPerformed(evt);
            }
        });

        ClassificaMediumButton.setText("Classifica Medium");
        ClassificaMediumButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassificaMediumButtonActionPerformed(evt);
            }
        });

        ClassificaAdvancedButton.setText("Classifica Advanced");
        ClassificaAdvancedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassificaAdvancedButtonActionPerformed(evt);
            }
        });

        ClassificaReturnButton.setText("Return");
        ClassificaReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassificaReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ClassificaSelectorPanelLayout = new javax.swing.GroupLayout(ClassificaSelectorPanel);
        ClassificaSelectorPanel.setLayout(ClassificaSelectorPanelLayout);
        ClassificaSelectorPanelLayout.setHorizontalGroup(
            ClassificaSelectorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ClassificaSelectorPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ClassificaReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(ClassificaSelectorPanelLayout.createSequentialGroup()
                .addContainerGap(53, Short.MAX_VALUE)
                .addGroup(ClassificaSelectorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ClassificaAdvancedButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ClassificaMediumButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ClassificaEasyButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        ClassificaSelectorPanelLayout.setVerticalGroup(
            ClassificaSelectorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ClassificaSelectorPanelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(ClassificaEasyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ClassificaMediumButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ClassificaAdvancedButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(ClassificaReturnButton)
                .addContainerGap())
        );

        CreditiPanel.setBackground(new java.awt.Color(192, 192, 192));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Autori");

        jLabel2.setText("Cotugno Thomas");

        jLabel3.setText("Gariboldi Giacomo");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Contributo al codice");

        jLabel5.setText("Prof. Laura Pavia");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Grafica");

        jLabel8.setText("Giacomo Gariboldi");

        jLabel9.setText("Tema Base");

        jLabel10.setText("Tema Scuro");

        jLabel11.setText("Prato Fiorito");

        jLabel12.setText("Sito Navale");

        jLabel13.setText("Spazio");

        jLabel14.setText("Cimitero");

        jLabel15.setText("Thomas Cotugno");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("Altri spunti per il codice");

        jLabel17.setText("zetcode.com");

        jLabel18.setText("betterprogramming.pub");

        jLabel19.setText("tutorialflow.com");

        jLabel20.setText("The coding train on YouTube");

        jLabel21.setText("Tangos974 on Reddit");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setText("Casella preferita");

        jLabel23.setText("Giacomo Gariboldi");

        jLabel24.setText("Thomas Cotugno");

        TilePreferitaGiacomo.setText("Tile 9 Cimitero");

        TilePreferitaThomas.setText("Tile 10 Navale");

        CreditsReturnButton.setText("Return");
        CreditsReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreditsReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CreditiPanelLayout = new javax.swing.GroupLayout(CreditiPanel);
        CreditiPanel.setLayout(CreditiPanelLayout);
        CreditiPanelLayout.setHorizontalGroup(
            CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CreditiPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CreditiPanelLayout.createSequentialGroup()
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE))
                            .addComponent(jLabel8)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(27, 27, 27))
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(CreditiPanelLayout.createSequentialGroup()
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(CreditiPanelLayout.createSequentialGroup()
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE))
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CreditiPanelLayout.createSequentialGroup()
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(TilePreferitaThomas, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(46, 46, 46))
                            .addGroup(CreditiPanelLayout.createSequentialGroup()
                                .addComponent(TilePreferitaGiacomo, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(CreditsReturnButton)
                                .addContainerGap())))))
        );
        CreditiPanelLayout.setVerticalGroup(
            CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CreditiPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(CreditiPanelLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3))
                    .addGroup(CreditiPanelLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addGap(22, 22, 22)))
                .addGap(31, 31, 31)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGap(10, 10, 10)
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel12))
                .addGap(32, 32, 32)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel17)
                        .addComponent(jLabel21)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel20))
                .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CreditiPanelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel22)
                        .addGap(25, 25, 25)
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(jLabel24))
                        .addGap(18, 18, 18)
                        .addGroup(CreditiPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TilePreferitaGiacomo, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TilePreferitaThomas, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CreditiPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(CreditsReturnButton)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MenuStartPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(CampoDiGiocoPanelBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(DifficultyEditorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ThemeEditorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ClassificaSelectorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(CreditiPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MenuStartPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(CampoDiGiocoPanelBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(DifficultyEditorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ThemeEditorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ClassificaSelectorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(CreditiPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NuovaPartitaBottoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuovaPartitaBottoneActionPerformed
        //New Game
        
        //Apro il pannello di gioco
        MenuStartPanel.setVisible(false);
        CampoDiGiocoPanelBase.setVisible(true);
        
        //Nuova matrice di bottoni
        campoClient = new JButton[campoServer.getWidth()][campoServer.getHeight()];
        
        // Massimizza la finestra PRIMA di calcolare le dimensioni
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        revalidate(); // Forza il layout a ricalcolarsi
       
        //Reset di tutte le variabili relative al gioco
        primoClick = true;
        tilesScoperte = 0;
        
        //Pulizia panel e lato server
        CampoDiGiocoPanelCenter.removeAll();
        campoServer.resetBoard();
        
        //Base per il panel
        CampoDiGiocoPanelCenter.setLayout(
            new GridLayout(campoServer.getWidth(), campoServer.getHeight()));
        
        //Nuova matrice per coperto, scoperto e bandiera
        cellaScoperta = new int[campoServer.getWidth()][campoServer.getHeight()];
        
        //Faccina
        resetButton.setIcon(new ImageIcon(getClass().getResource("Smiley.png")));
        
        //Fermo il timer e resetto il label
        if (gameTimer != null) {
            gameTimer.stop();
        }
        timerLabel.setText("000");
        
        //Resetto il conteggio delle bombe
        bombCounter = 0;
        bombCounterLabel.setText(String.valueOf(numBombe));
        
        homeButton.setIcon(new ImageIcon(getClass().getResource("home.png")));
        
        for (int i = 0; i < campoServer.getWidth(); i++)
            for(int j = 0; j < campoServer.getHeight(); j++)
            {
                //Associa ad ogni cella un nuovo bottone
                campoClient[i][j] = new JButton();
                
                //Salvo le coordinate del bottone nel bottone stesso cosicché
                //Io non debba fare doppi for per trovare il bottone premuto
                campoClient[i][j].putClientProperty("x", i);
                campoClient[i][j].putClientProperty("y", j);
                
                //Rendo cliccabili
                campoClient[i][j].addMouseListener(ascoltaMouse);
                //Aggiungo al pannello
                CampoDiGiocoPanelCenter.add(campoClient[i][j]);
                //Gli do l'immagine della cella coperta
                campoClient[i][j].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile11.png")));
            }
        
        //Ridimensiono la finestra
        //pack();
        //setSize(400, 600);                //Impostare dimensioni appropriate per la finestra
    }//GEN-LAST:event_NuovaPartitaBottoneActionPerformed

    private void DifficoltaBottoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DifficoltaBottoneActionPerformed
        //Editor difficolta'
        
        //Mostro il pannello per l'editor della difficolta'
        MenuStartPanel.setVisible(false);
        DifficultyEditorPanel.setVisible(true);
        
        //Ridimensiono
        pack();
        setSize(178, 248);;                  //Cambia dimensioni
    }//GEN-LAST:event_DifficoltaBottoneActionPerformed

    private void TemaBottoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TemaBottoneActionPerformed
        //Editor temi
        
        //Mostro il pannello per l'editor dei temi
        MenuStartPanel.setVisible(false);
        ThemeEditorPanel.setVisible(true);
        
        //Ridimensiono
        pack();
        setSize(198, 410);                  //Cambia dimensioni
    }//GEN-LAST:event_TemaBottoneActionPerformed

    private void ClassificaBottoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassificaBottoneActionPerformed
        MenuStartPanel.setVisible(false);
        ClassificaSelectorPanel.setVisible(true);
        
        //Ridimensiono
        pack();
        setSize(260, 270); 
        //Classifica (da dividere per difficolta')
    }//GEN-LAST:event_ClassificaBottoneActionPerformed

    private void homeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeButtonActionPerformed
        //Home button from partita in corso
        
        //Ritorno al pannello di start
        MenuStartPanel.setVisible(true);
        CampoDiGiocoPanelBase.setVisible(false);
        
        //Pulizia del pannello di gioco
        CampoDiGiocoPanelCenter.removeAll();
        
        //Ridimensiono
        pack();
        setSize(272, 360);
    }//GEN-LAST:event_homeButtonActionPerformed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        //Smiley face reset button

        //Resetto il pannello di gioco
        CampoDiGiocoPanelBase.setVisible(false);
        CampoDiGiocoPanelBase.setVisible(true);
        
        //Nuova matrice
        campoClient = new JButton[campoServer.getWidth()][campoServer.getHeight()];
        
        //Reset variabili
        primoClick = true;
        tilesScoperte = 0;
        
        //Reset pannello e server side
        CampoDiGiocoPanelCenter.removeAll();
        campoServer.resetBoard();
        
        //Stendo griglia
        CampoDiGiocoPanelCenter.setLayout(
            new GridLayout(campoServer.getWidth(), campoServer.getHeight()));
        
        //Nuova mat x valori scoperta, coperta e bandiera
        cellaScoperta = new int[campoServer.getWidth()][campoServer.getHeight()];
        
        //Fermo il timer e resetto il label
        if (gameTimer != null) {
            gameTimer.stop();
        }
        timerLabel.setText("000");
        
        //Resetto il conteggio delle bombe
        bombCounter = 0;
        bombCounterLabel.setText(String.valueOf(numBombe));
        
        for (int i = 0; i < campoServer.getWidth(); i++)
            for(int j = 0; j < campoServer.getHeight(); j++)
            {
                //Riaggiungo come in precedenza
                campoClient[i][j] = new JButton();
                campoClient[i][j].putClientProperty("x", i);
                campoClient[i][j].putClientProperty("y", j);
                campoClient[i][j].addMouseListener(ascoltaMouse);
                campoClient[i][j].setIcon(new ImageIcon(getClass().getResource(theme + "/Tile11.png")));
                CampoDiGiocoPanelCenter.add(campoClient[i][j]);
            }
        resetButton.setIcon(new ImageIcon(getClass().getResource("Smiley.png")));
    }//GEN-LAST:event_resetButtonActionPerformed

    private void difficultyEasyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_difficultyEasyButtonActionPerformed
        //Easy mode
        lunghezza = 9;
        altezza = 9;
        numBombe = 10;
        difficolta = "facile.txt";
        
        //Ridimensiona il campo di gioco
        campoServer = new GameBoard(lunghezza, altezza, numBombe);
        
        //Messaggio di conferma
        cambio("difficolta", 'a');
    }//GEN-LAST:event_difficultyEasyButtonActionPerformed

    private void difficultyMediumButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_difficultyMediumButtonActionPerformed
        //Medium mode
        lunghezza = 12;
        altezza = 12;
        numBombe = 25;
        difficolta = "medium.txt";
        //Ridimensiona il campo di gioco
        campoServer = new GameBoard(lunghezza, altezza, numBombe);
        
        //Messaggio di conferma
        cambio("difficolta", 'a');
    }//GEN-LAST:event_difficultyMediumButtonActionPerformed

    private void difficultyAdvancedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_difficultyAdvancedButtonActionPerformed
        //Advanced mode
        lunghezza = 16;
        altezza = 16;
        numBombe = 40;
        difficolta = "advanced.txt";
        //Ridimensiona il campo di gioco
        campoServer = new GameBoard(lunghezza, altezza, numBombe);
        
        //Messaggio di conferma
        cambio("difficolta", 'a');
    }//GEN-LAST:event_difficultyAdvancedButtonActionPerformed

    private void ThemeBaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeBaseButtonActionPerformed
        //Base
        theme = "Base";
        
        //Messaggio di conferma
        cambio("tema", 'o');
        mistoSpazio = false;
        mistoPrato = false;
    }//GEN-LAST:event_ThemeBaseButtonActionPerformed

    private void ThemeDarkButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeDarkButtonActionPerformed
        //Dark
        theme = "Dark";
        
        //Messaggio di conferma
        cambio("tema", 'o');
        mistoSpazio = false;
        mistoPrato = false;
    }//GEN-LAST:event_ThemeDarkButtonActionPerformed

    private void ThemePratoFioritoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemePratoFioritoButtonActionPerformed
        //CampoFiorito
        theme = "CampoFiorito";
        
        //Messaggio di conferma
        cambio("tema", 'o');
        mistoPrato = true;
        mistoSpazio = false;
    }//GEN-LAST:event_ThemePratoFioritoButtonActionPerformed

    private void ThemeMareButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeMareButtonActionPerformed
        //Mare
        theme = "SitoNavale";
        
        //Messaggio di conferma
        cambio("tema", 'o');
        mistoSpazio= false;
        mistoPrato = false;
    }//GEN-LAST:event_ThemeMareButtonActionPerformed

    private void ThemeCimiteroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeCimiteroButtonActionPerformed
        //Cimitero
        theme = "Cimitero";
        
        //Messaggio di conferma
        cambio("tema", 'o');
        mistoSpazio = false;
        mistoPrato = false;
    }//GEN-LAST:event_ThemeCimiteroButtonActionPerformed

    private void ThemeSpazioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeSpazioButtonActionPerformed
        //Spazio
        theme = "Spazio";
        
        //Messaggio di conferma
        cambio("tema", 'o');
        mistoSpazio = true;
        mistoPrato = false;
    }//GEN-LAST:event_ThemeSpazioButtonActionPerformed

    private void ThemeRandomButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeRandomButtonActionPerformed
        //Random
        Random genera = new Random();
        int numero = genera.nextInt(6);
        switch(numero) {
            case 0:
               theme = "Base";
               mistoSpazio = false;
               mistoPrato = false;
               break;
            case 1:
                theme = "Dark";
                mistoSpazio = false;
                mistoPrato = false;
                break;
            case 2:
                theme = "CampoFiorito";
                mistoPrato = true;
                mistoSpazio = false;
                break;
            case 3:
                theme = "SitoNavale";
                mistoSpazio = false;
                mistoPrato = false;
                break;
            case 4:
                theme = "Cimitero";
                mistoSpazio = false;
                mistoPrato = false;
                break;
            case 5:
                theme = "Spazio";
                mistoSpazio = true;
                mistoPrato = false;
                break;
            default: 
                JOptionPane.showMessageDialog(this, "Errore nell'aggiornamento dei temi", "ERRORE", 0); 
        }
        
        //Messaggio di conferma
        cambio("tema", 'o');
    }//GEN-LAST:event_ThemeRandomButtonActionPerformed

    private void DifficultyEditorReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DifficultyEditorReturnButtonActionPerformed
        // Return Difficulty Editor
        
        //Torna a start panel
        DifficultyEditorPanel.setVisible(false);
        MenuStartPanel.setVisible(true);
        
        //Ridimensiono
        pack();
        setSize(272, 360);
    }//GEN-LAST:event_DifficultyEditorReturnButtonActionPerformed

    private void ThemeEditorReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemeEditorReturnButtonActionPerformed
        // Return Theme Editor
        
        //Torna a start panel
        ThemeEditorPanel.setVisible(false);
        MenuStartPanel.setVisible(true);

        //Ridimensiono
        pack();
        setSize(272, 360);
    }//GEN-LAST:event_ThemeEditorReturnButtonActionPerformed

    private void CreditsReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreditsReturnButtonActionPerformed
        // Return from Crediti
        
        //Torna a start panel
        CreditiPanel.setVisible(false);
        MenuStartPanel.setVisible(true);

        //Ridimensiono
        pack();
        setSize(272, 360);
    }//GEN-LAST:event_CreditsReturnButtonActionPerformed

    private void CreditiBottoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreditiBottoneActionPerformed
        // Crediti
        
        //Mostro il pannello per i crediti
        MenuStartPanel.setVisible(false);
        CreditiPanel.setVisible(true);
        
        //Setto le tiles preferite
        TilePreferitaGiacomo.setText("");
        TilePreferitaGiacomo.setIcon(new ImageIcon(getClass().getResource("TilePreferitaGiacomo.png")));
        TilePreferitaThomas.setText("");
        TilePreferitaThomas.setIcon(new ImageIcon(getClass().getResource("SitoNavale//Tile10.png")));
        
        //Ridimensiono
        pack();
        setSize(360, 610);                      //Da ridimensionare
    }//GEN-LAST:event_CreditiBottoneActionPerformed

    private void ClassificaEasyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassificaEasyButtonActionPerformed
        // TODO add your handling code here:
        Classifica.lettura("facile.txt");
    }//GEN-LAST:event_ClassificaEasyButtonActionPerformed

    private void ClassificaReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassificaReturnButtonActionPerformed
        //Torna a start panel
        ClassificaSelectorPanel.setVisible(false);
        MenuStartPanel.setVisible(true);

        //Ridimensiono
        pack();
        setSize(272, 342);
        // TODO add your handling code here:     

    }//GEN-LAST:event_ClassificaReturnButtonActionPerformed

    private void ClassificaMediumButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassificaMediumButtonActionPerformed
        // TODO add your handling code here:
        Classifica.lettura("medium.txt");
    }//GEN-LAST:event_ClassificaMediumButtonActionPerformed

    private void ClassificaAdvancedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassificaAdvancedButtonActionPerformed
        // TODO add your handling code here:
        Classifica.lettura("advanced.txt");
    }//GEN-LAST:event_ClassificaAdvancedButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Finestra1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Finestra1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Finestra1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Finestra1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Finestra1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CampoDiGiocoPanelBase;
    private javax.swing.JPanel CampoDiGiocoPanelCenter;
    private javax.swing.JPanel CampoDiGiocoPanelTop;
    private javax.swing.JButton ClassificaAdvancedButton;
    private javax.swing.JButton ClassificaBottone;
    private javax.swing.JButton ClassificaEasyButton;
    private javax.swing.JButton ClassificaMediumButton;
    private javax.swing.JButton ClassificaReturnButton;
    private javax.swing.JPanel ClassificaSelectorPanel;
    private javax.swing.JButton CreditiBottone;
    private javax.swing.JPanel CreditiPanel;
    private javax.swing.JButton CreditsReturnButton;
    private javax.swing.JButton DifficoltaBottone;
    private javax.swing.JPanel DifficultyEditorPanel;
    private javax.swing.JButton DifficultyEditorReturnButton;
    private javax.swing.JPanel MenuStartPanel;
    private javax.swing.JButton NuovaPartitaBottone;
    private javax.swing.JButton TemaBottone;
    private javax.swing.JButton ThemeBaseButton;
    private javax.swing.JButton ThemeCimiteroButton;
    private javax.swing.JButton ThemeDarkButton;
    private javax.swing.JPanel ThemeEditorPanel;
    private javax.swing.JButton ThemeEditorReturnButton;
    private javax.swing.JButton ThemeMareButton;
    private javax.swing.JButton ThemePratoFioritoButton;
    private javax.swing.JButton ThemeRandomButton;
    private javax.swing.JButton ThemeSpazioButton;
    private javax.swing.JLabel TilePreferitaGiacomo;
    private javax.swing.JLabel TilePreferitaThomas;
    private javax.swing.JLabel bombCounterLabel;
    private javax.swing.JButton difficultyAdvancedButton;
    private javax.swing.JButton difficultyEasyButton;
    private javax.swing.JButton difficultyMediumButton;
    private javax.swing.JButton homeButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton resetButton;
    private javax.swing.JLabel timerLabel;
    // End of variables declaration//GEN-END:variables
//Variabile per la classe
GameBoard campoServer;
//Nuova matrice di bottoni
JButton campoClient[][];
//Valori per le difficolta' (base)
int lunghezza = 9, altezza = 9, numBombe = 10;
//Valori per indicare: 0 = coperta | 1 = scoperta | 2 = bandiera
int[][] cellaScoperta;    
//Boolean per evitare che esploda al primo, al primo stendi bombe
boolean primoClick = true;
//Counter per sapere quando si vince
int tilesScoperte;
//Permette di premere il bottone e -- quando rimosso -- *dovrebbe* non essere piu' cliccabile 
private AscoltaMouse ascoltaMouse = new AscoltaMouse();
//Variabile per settare i temi, parte come base
String theme = "Base";
//Variabili x timer
Timer gameTimer;
int tempo;
//Variabile x counter di bombe in alto a sx
int bombCounter = 0;
String difficolta ="facile.txt";
//flag per tiles miste
boolean mistoPrato = false;
boolean mistoSpazio = false;
int randomNum;
Random rand = new Random();
}
