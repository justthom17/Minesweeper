import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nonGalimberti
 */
public class GameBoard {
    
    private int gameBoard[][];
    
    private int boardWidth,
            boardHeight,
            numBombe;
    
    public GameBoard()
    {
        boardWidth = 9;
        boardHeight = 9;
        gameBoard = new int [boardWidth][boardHeight];
    }
    
    public GameBoard(int boardWidth, int boardHeight, int numBombe)
    {
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
        gameBoard = new int [boardWidth][boardHeight];
        if(numBombe <= 0)
             throw new IllegalArgumentException("numero invalido per contatore bombe");
        else
            this.numBombe = numBombe;
    }
    
    public GameBoard(GameBoard g)
    {
        boardWidth = g.boardWidth;
        boardHeight = g.boardHeight;
        gameBoard = new int [boardWidth][boardHeight];
        numBombe = g.numBombe;
    }
    
    public void set(int boardWidth, int boardHeight, int numBombe)
    {
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
        this.numBombe = numBombe;
    }
    
    public void setNumBombe(int numBombe)
    {
            this.numBombe = numBombe;
    }
    
    public void setWidth(int boardWidth)
    {
        this.boardWidth = boardWidth;
    }
    
    public void setHeight(int boardHeight)
    {
        this.boardHeight = boardHeight;
    }
    
    public int getNumBombe()
    {
        return numBombe;
    }
     
    public int getWidth()
    {
        return boardWidth;
    }
    
    public int getHeight()
    {
        return boardHeight;
    }
    
    public int getValueOnBoard(int x, int y)
    {
        return gameBoard[x][y];
    }
    
    public void stesuraMine(int xO, int yO)
    {
        int minesAdded = 0;
        int i, j;
        Random rd = new Random();

        while(minesAdded != numBombe) {
            i = rd.nextInt(boardWidth);	//Genera rndm number tra valori width
            j = rd.nextInt(boardHeight);	//Genera rndm number tra valori height

            /* ---Spiegazione funziona Math.abs---
            Math.abs restituisce il valore assoluto di un calcolo
            In questo caso stiamo controllando se la distanza tra i e xO
            sia maggiore di uno (3x3) --> (+1, 0, -1) crea un 3x1, aggiungi l'altra variabile = 3x3
            in tal caso ci troviamo ad una distanza appropriata a cui mettere una bomba
            */
            if(gameBoard[i][j] != 9 && (Math.abs(i - xO) > 1 || Math.abs(j - yO) > 1)){
                    gameBoard[i][j] = 9;
                    minesAdded++;
            }
        }

        for(i=0; i<boardWidth; i++)
            for(j=0; j<boardHeight;j++)
                if(gameBoard[i][j]!=9) 
                    gameBoard[i][j]=countNghbrMines(i,j);
    }
    
    public int countNghbrMines(int x, int y)
    {
        //Codificare un conto per mine vicine
        int mineCounter = 0;
        //Controllo per evitare fuori da tabella di gioco
        //Riscriverlo in modo da dare x e y a getCell per celle da controllare
        
        for(int i = x - 1; i < x + 2; i++)
            for(int j = y - 1; j < y + 2; j++)
            {
                if(i >= 0 && i < getWidth() && j >= 0 && j < getHeight())
                    if(gameBoard[i][j] == 9)
                        mineCounter++;
            }
        return mineCounter;
    }
    
    public void resetBoard() {
        gameBoard = new int[boardWidth][boardHeight];
    }
    
}
